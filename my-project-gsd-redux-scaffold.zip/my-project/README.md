# My Project

> One sentence: what this is and who it's for.

A **multi-CLI, spec-driven** project. Designed to be driven with **Codex**,
**Claude Code**, and **GSD Redux** (`open-gsd/get-shit-done-redux`) without the agents
tripping over each other — while staying browsable in [Obsidian](https://obsidian.md)
(open this folder as a vault).

## The one rule that makes multi-CLI work
**`AGENTS.md` is the single source of truth.** Every CLI reads it. Tool-specific files
(`CLAUDE.md`, `.codex/config.toml`, `.cursorrules`, Copilot instructions) only *point*
to it and add tool-specific notes — they never contradict it. Change rules in `AGENTS.md`
and nowhere else.

> **Heads up:** if you install **GSD Redux**, GSD will rewrite `AGENTS.md` and own several
> root-level files (`PROJECT.md`, `REQUIREMENTS.md`, `ROADMAP.md`, `STATE.md`, `CONTEXT.md`).
> Read `external/GSD-INTEGRATION.md` BEFORE running `/gsd-new-project` and pick a mode
> (GSD-led or docs-led). Record the choice in `02-notes/decisions/`.

## Map
| Path | What it is |
|---|---|
| `AGENTS.md` | **Source of truth.** Rules every agent obeys. Edit this first (until GSD takes over). |
| `CLAUDE.md` | Claude Code entry point — imports `AGENTS.md`. |
| `.codex/config.toml` | Codex project config (registers skills; Codex reads AGENTS.md automatically). Requires Codex CLI ≥ 0.130.0 for GSD compatibility. |
| `.cursorrules`, `.github/copilot-instructions.md` | Stubs pointing back to AGENTS.md. |
| `00-planning/` | vision, requirements, design, roadmap, tasks, and the **handoff log**. (GSD-led mode supersedes most of these with root-level files.) |
| `00-planning/handoff.md` | The **baton** between agents. (Becomes `STATE.md` at root when GSD is installed.) |
| `01-features/` | One mini-spec per feature (copy `_template/`). |
| `02-notes/` | Research, daily logs, decision log. |
| `skills/` | Project-local SKILL.md modules — work in Claude Code AND Codex. |
| `external/` | External repos/frameworks. Agents extend, never edit. |
| `external/GSD-INTEGRATION.md` | **Read this before installing GSD.** Install command, file ownership, mode choice. |
| `src/` `tests/` `tooling/` | Code, tests, helper scripts. |
| `CHANGELOG.md` | Plain-English log of changes. |

## Daily loop (any CLI)
1. **Read `AGENTS.md` + the handoff file** (`00-planning/handoff.md`, or `STATE.md` if GSD is active).
2. Make sure the task is specced (in `00-planning/` / a feature folder / a GSD phase). If not, spec it.
3. Make one focused change. Commit it.
4. **Update the handoff file, tick the task, add a `CHANGELOG.md` line.** Then you (or the next tool) can pick up clean.

## Starting from zero — the right-foot checklist
1. Fill in `AGENTS.md` §1 (what we're building) and §2 (tech stack).
2. Decide: are you using GSD? Read `external/GSD-INTEGRATION.md` and pick GSD-led or docs-led.
3. Record that choice as an ADR in `02-notes/decisions/`.
4. If GSD: install with `npx @opengsd/get-shit-done-redux@latest`, restart your CLI, run `/gsd-new-project`.
5. If not GSD: fill in `00-planning/vision.md` → `requirements.md` → `design.md` → `roadmap.md` → `tasks.md`.
6. Either way: commit. Now you're ready to build.

## Switching tools mid-project
Commit → update handoff file → switch. The next agent reads git + the handoff, not your memory. One driver at a time on a given branch (or use separate git branches/worktrees for parallel work).
