# Research: <topic>

Links, quotes, and findings. In Obsidian you can link to other notes with [[double brackets]].

## Takeaway
The one thing this changes about the plan.
