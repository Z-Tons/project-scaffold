# 0001 — Use markdown files for all planning

- **Date:** 2026-01-01
- **Status:** accepted

## Context
We need planning docs that both a human (via Obsidian) and an AI coding tool can read.

## Decision
Keep everything as plain markdown in this folder. No external database or proprietary format.

## Why / tradeoffs
- + No lock-in, version-controllable, AI-readable, Obsidian-readable.
- - Less structured than a dedicated PM tool.

## Consequences
Every plan, spec, and note is a `.md` file committed to git.
