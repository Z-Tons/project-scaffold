# 0002 — GSD usage mode

- **Date:** TODO
- **Status:** proposed

## Context
We're starting a multi-CLI coding project (Codex + Claude Code, possibly others).
GSD Redux (`open-gsd/get-shit-done-redux`) is on the table. GSD writes/owns specific
files at the project root (`PROJECT.md`, `REQUIREMENTS.md`, `ROADMAP.md`, `STATE.md`,
`CONTEXT.md`, `AGENTS.md`, plus `.planning/`, `.plans/`, etc.) — which overlaps directly
with our scaffold's `00-planning/` folder. Running both as the system of record causes
agents to read contradictory plans.

See `external/GSD-INTEGRATION.md` for the full file-ownership table.

## Decision
Pick ONE — and commit to it before running `/gsd-new-project`:

- [ ] **A. GSD-led.** GSD owns specs/plans/state at the root. Our `00-planning/` is for
      non-GSD artifacts only (design sketches, ad-hoc notes). GSD rewrites `AGENTS.md`.
- [ ] **B. Docs-led.** Our `00-planning/*.md` files stay the source of truth. We use GSD
      only for its execution loop (`/gsd-execute-phase`, `/gsd-verify-work`).
- [ ] **C. No GSD (yet).** Pure docs-led; revisit later.

## Why / tradeoffs
- A: cleanest separation, but you live in GSD's structure. Best once you've tried GSD and like it.
- B: keeps your familiar layout, but you'll duplicate spec info. Pick only if you have a reason.
- C: simplest. Lose GSD's context-rot defense and subagent orchestration.

## Consequences
Once chosen, update `AGENTS.md` §3 accordingly and follow the install steps in
`external/GSD-INTEGRATION.md`. If you later switch modes, write a follow-up ADR.
