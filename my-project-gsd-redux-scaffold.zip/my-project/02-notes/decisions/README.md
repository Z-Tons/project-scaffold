# Decision log (ADRs)

When you make a real choice (a tradeoff, a tech pick, a "we're NOT doing X"),
copy `0001-example-decision.md` to the next number and fill it in.
Future-you (and the AI) will thank you for knowing *why* things are the way they are.
