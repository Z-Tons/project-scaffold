# AGENTS.md — Single Source of Truth for ALL agents

> **This is the canonical rulebook.** Codex reads it natively (project root).
> Claude Code reads it via an import in `CLAUDE.md`. Cursor/Copilot/Windsurf
> point here too. Every CLI obeys THIS file so they can't contradict each other.
> If a rule changes, change it HERE and nowhere else.

---

## 1. What we're building
TODO: 2-3 sentences. What it is, who it's for, why it exists. (Source: `00-planning/vision.md`)

## 2. Tech stack (do not deviate without asking)
- Language:
- Framework:
- Database / storage:
- Hosting:
- Package manager:

## 3. Project map
- `AGENTS.md` (this file) — the rules. **Read first, every session.**
- `00-planning/` — vision, requirements, design, roadmap, tasks, **handoff log**.
- `01-features/` — one mini-spec per feature.
- `skills/` — reusable SKILL.md modules (work in BOTH Claude Code and Codex).
- `external/` — external repos / frameworks pulled in (e.g. GSD). See `external/README.md`.
- `src/` — code. `tests/` — tests. `tooling/` — scripts that aren't app code.

### If GSD (Get Shit Done — Redux) is installed
GSD writes/owns these files at the project root (see `external/GSD-INTEGRATION.md`):
`PROJECT.md`, `REQUIREMENTS.md`, `ROADMAP.md`, `STATE.md`, `CONTEXT.md`, and the
`.planning/`, `.plans/`, `.out-of-scope/`, `agents/`, `commands/gsd/` directories.
GSD also rewrites this `AGENTS.md`. When GSD is active, **`STATE.md` is the handoff log**
(not `00-planning/handoff.md`), and `PROJECT.md`/`REQUIREMENTS.md`/`ROADMAP.md` supersede
the matching files in `00-planning/`. The chosen mode (GSD-led vs docs-led) is recorded
in `02-notes/decisions/`.

## 4. Universal working rules (every agent, every session)
1. **Read `00-planning/handoff.md` FIRST** (or `STATE.md` at project root if GSD is installed). It says what the last agent did and what's next.
2. **Plan before code.** If a task isn't specced in `00-planning/` or `01-features/`, write the spec or ask — don't improvise.
3. **One focused change at a time.** No giant rewrites. Atomic, revertable commits.
4. **Don't invent scope.** Build exactly what's asked. Flag assumptions, don't bury them.
5. **Match existing patterns.** Read nearby code before adding new code.
6. **Stay in the stack (§2).** No new library/framework without asking.
7. **Never edit `external/`** contents directly — those are vendored. Wrap or extend them in `src/`.
8. **On finishing a unit of work, you MUST:**
   - Update `00-planning/handoff.md` (what you did, current state, next step).
   - Check off the task in `00-planning/tasks.md`.
   - Add a line to `CHANGELOG.md`.
   - Record any real tradeoff/decision in `02-notes/decisions/`.

## 5. Multi-CLI coordination (CRITICAL)
We run more than one agent (e.g. Codex AND Claude Code, plus GSD on top).
- **One agent owns the repo at a time** for a given task. Don't run two agents editing the same files in parallel unless using separate git branches/worktrees.
- **The handoff log is the baton.** Switching tools = read `handoff.md`, then update it when you stop.
- **Commit before switching tools.** The next agent reads git + handoff, not your memory.
- **If two tools disagree, AGENTS.md wins.** Tool-specific files only ADD detail; they never override §1–§8.

## 6. Commands
- Install:
- Run:
- Test:
- Build:
- Lint/format:

## 7. Do NOT touch
- Anything in `external/` (vendored — extend, don't edit).
- TODO: fragile/load-bearing files.
