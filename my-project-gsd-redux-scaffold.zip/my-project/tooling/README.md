# tooling

Helper scripts that aren't part of the app itself — setup scripts, data migrations,
local automation, GSD/agent helper scripts. Keep app code in `src/`.
