<!--
HOW TO USE THIS FILE
1. Start a new Claude session.
2. Attach: (a) the project scaffold .zip, and (b) your project idea write-up
   (as a file, OR pasted into the "PROJECT IDEA" section at the bottom of this file).
3. Paste this entire file as your first message.
-->

# Project Kickoff — Bootstrap My Scaffold From My Idea

You are helping me start a **multi-CLI, spec-driven coding project**. I run it with
multiple AI coding tools (e.g. Codex + Claude Code) and I'm planning to use
**GSD Redux** (`open-gsd/get-shit-done-redux`, npm `@opengsd/get-shit-done-redux`).
I've attached:

1. **A project scaffold (.zip)** — opinionated folder structure with planning docs,
   tool config, a skills folder, and an `external/` area documenting GSD integration.
2. **My project idea** — attached or pasted at the bottom.

## Step 1 — Inspect the scaffold first
- Extract the zip and produce a short inventory of the folder tree.
- **Read these files fully:** `AGENTS.md`, `README.md`, `00-planning/handoff.md`,
  `00-planning/vision.md`, `00-planning/requirements.md`, `00-planning/design.md`,
  `00-planning/roadmap.md`, `00-planning/tasks.md`, `skills/README.md`,
  `external/README.md`, **`external/GSD-INTEGRATION.md`**, `.codex/config.toml`,
  and the seeded ADRs in `02-notes/decisions/`.
- Then tell me, in ~5 bullets, what you understand about how this project is meant to
  be run — including the GSD file-ownership rules and the GSD-led vs docs-led choice.

## Step 2 — Read my idea and ask only what's blocking
Ask a short batch of clarifying questions only as needed. Must cover:
- Tech stack (language, framework, storage, hosting, package manager).
- The v1 walking skeleton.
- Out of scope for now.
- **GSD mode: A (GSD-led), B (docs-led + GSD execution), or C (no GSD yet)?**
- Which CLIs (Codex, Claude Code, etc.) and Codex CLI version if known (≥ 0.130.0 needed for GSD).

## Step 3 — Populate the scaffold
Fill in placeholders/TODOs. Specifically:
- `AGENTS.md` §1, §2, §6, §7.
- `00-planning/vision.md`, `requirements.md`, `design.md`, `roadmap.md`, `tasks.md`.
- First feature folder under `01-features/`.
- `00-planning/handoff.md` CURRENT STATE.
- **Complete `02-notes/decisions/0002-gsd-mode.md`** with the chosen mode and reasoning.
- `CHANGELOG.md` "project initialized" line.

If the user chose GSD-led (A): note in tasks/handoff that running `/gsd-new-project`
WILL rewrite AGENTS.md and generate `PROJECT.md`, `REQUIREMENTS.md`, `ROADMAP.md`,
`STATE.md` at the root — those will then supersede the matching `00-planning/` files.

## Rules
- `AGENTS.md` is the source of truth. Don't put rules in other config files that contradict it.
- Don't write application code yet. Planning step only.
- Don't edit `external/` contents.
- Mark assumptions clearly so they can be corrected.

## Step 4 — Deliver
- Re-zip the populated scaffold and give it back as a download.
- Summary of what was filled in / assumed / still open.
- The exact next 1–3 commands to start (e.g. `npx @opengsd/get-shit-done-redux@latest` then `/gsd-new-project`, or the docs-led equivalent).

---

## PROJECT IDEA
<!-- Paste your write-up here, OR delete this section and attach it as a file. -->

(your project idea goes here)
