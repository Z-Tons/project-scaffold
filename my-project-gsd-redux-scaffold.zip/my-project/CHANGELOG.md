# Changelog

Plain-English log of what changed. Newest on top. One line per meaningful change.

## Unreleased
- Aligned scaffold to **GSD Redux** (`open-gsd/get-shit-done-redux`): correct npm package, install command, six-command loop, file-ownership table, Codex ≥ 0.130.0 requirement.
- Removed references to the legacy GSD upstream (trust/continuity issue).
- Pre-seeded ADR `0002-gsd-mode.md` for the GSD-led vs docs-led decision.
- Updated `.gitignore` to commit GSD planning artifacts (so all CLIs share state) while ignoring caches.
- Updated handoff log to defer to `STATE.md` when GSD is installed.
- Converted to multi-CLI layout: AGENTS.md is now the single source of truth.
- Added Codex config (.codex/config.toml), CLI stubs (.cursorrules, Copilot).
- Added external/ for vendored repos + GSD integration guide.
- Added 00-planning/handoff.md as the cross-agent baton.
- Set up project structure and planning docs.
