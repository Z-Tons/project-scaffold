# GSD (Get Shit Done — Redux) Integration

This project is designed to work with **GSD Redux**, the actively maintained fork:
**https://github.com/open-gsd/get-shit-done-redux**

GSD is a meta-prompting / context-engineering / spec-driven system that bolts a
structured workflow onto your AI CLI. It exists to fight **context rot** — the quality
drop as an agent's context window fills — by offloading work to fresh subagent contexts
and producing atomic, traceable commits.

It works with Claude Code, Codex, OpenCode, Gemini CLI, Kilo, Copilot, Cursor, Windsurf,
and others — which is why it fits a multi-CLI project: every tool runs the same workflow.

---

## ⚠️ Use the correct package — DO NOT use the legacy one

The original GSD upstream had a trust incident (publicly associated with a meme-coin
rug-pull) and is no longer maintained by the open-gsd team. Use only:

- **Repo:** `open-gsd/get-shit-done-redux` (branch: `next`)
- **npm (main):** `@opengsd/get-shit-done-redux`
- **npm (sdk):** `@opengsd/gsd-sdk`

If a legacy `get-shit-done-cc` or similar package is installed from before, remove it
before installing GSD Redux. Migration notes: open-gsd Discussions #109 (continuity)
and #119 (audit transparency).

---

## Install

```bash
# from the project root (this folder)
npx @opengsd/get-shit-done-redux@latest
```

The installer asks for your runtime (Claude Code, Codex, etc.) and whether to install
globally or locally, then drops the right files for that runtime. **Restart your CLI**
after install so the new commands/skills load.

### Runtime requirements
- **Codex CLI ≥ 0.130.0** — earlier versions discover skills from extra roots and you'll see duplicate `gsd-*` entries. Upgrade Codex or accept the duplication.
- **Claude Code** — run as `claude --dangerously-skip-permissions` (GSD is designed for frictionless automation).
- **Cross-runtime:** GSD source files are in Claude Code format; the installer converts them per target runtime. **Do NOT copy `agents/` or `commands/` files into a non–Claude-Code runtime config directly** — you'll get schema errors. Always use the installer.

---

## The six-command loop

| Command                      | What it does                                                |
|------------------------------|-------------------------------------------------------------|
| `/gsd-new-project`           | Questions → research → requirements → roadmap (project setup) |
| `/gsd-discuss-phase [N]`     | Capture implementation decisions BEFORE planning            |
| `/gsd-plan-phase [N]`        | Research + plan + verify (loop until plans pass)            |
| `/gsd-execute-phase <N>`     | Run plans in parallel waves, each in fresh subagent context |
| `/gsd-verify-work [N]`       | Manual acceptance test; failures get diagnosed fix plans    |
| `/gsd-ship [N]`              | Create PR from verified phase work                          |

Plus: `/gsd-progress --next`, `/gsd-complete-milestone`, `/gsd-new-milestone`,
`/gsd-map-codebase` (run first if you're bringing GSD to an existing codebase),
`/gsd-settings`, `/gsd:surface`.

**Returning to a project after a break?** Run `/gsd-map-codebase` then `/gsd-new-project`
to rebuild GSD's planning context. Your code is fine — only the context needs rebuilding.

---

## 🔑 File ownership — GSD vs this scaffold

This is the critical bit. GSD writes/manages specific files at the project root, and some
overlap directly with files in our `00-planning/` folder. **Read this before running
`/gsd-new-project`** so you don't end up with two systems of record.

### GSD owns these (it creates/updates them — don't hand-edit them while GSD is active)

| Path                  | Purpose                                                       | Overlaps with our scaffold |
|-----------------------|---------------------------------------------------------------|----------------------------|
| `AGENTS.md`           | Universal agent rules (GSD writes/updates)                   | **YES — our AGENTS.md**    |
| `PROJECT.md`          | Project vision                                                | `00-planning/vision.md`    |
| `REQUIREMENTS.md`     | Scope                                                         | `00-planning/requirements.md` |
| `ROADMAP.md`          | Phases / where you're going                                   | `00-planning/roadmap.md`   |
| `STATE.md`            | Current position, last actions, next step                     | `00-planning/handoff.md`   |
| `CONTEXT.md`          | Per-phase implementation decisions (from `/gsd-discuss-phase`) | (new — we don't have one)  |
| `.planning/`          | GSD config (`config.json`) and phase artifacts                | -                          |
| `.plans/`             | Generated plans from `/gsd-plan-phase`                        | -                          |
| `.out-of-scope/`      | Things explicitly deferred                                    | -                          |
| `agents/`             | GSD-installed agent definitions (Claude-Code source format)   | -                          |
| `commands/gsd/`       | GSD slash commands                                            | -                          |

### Files YOU still own (GSD leaves these alone)
- `00-planning/design.md` — architecture sketch (GSD doesn't generate this)
- `01-features/` — your feature mini-specs
- `02-notes/` — research, daily log, decision log (ADRs)
- `skills/` — your project-local skills (separate from GSD's installed skills at `~/.claude/skills/gsd-*` / `~/.codex/skills/gsd-*`)
- `src/`, `tests/`, `tooling/`
- `README.md`, `CHANGELOG.md`, `CLAUDE.md`, `.codex/config.toml`, `.cursorrules`

---

## Pick a mode BEFORE running `/gsd-new-project`

Two ways to run this; record your choice in `02-notes/decisions/` and follow it.

### Mode A — **GSD-led** (recommended once you're committed to GSD)
GSD owns the spec/plan/state files at root. The `00-planning/` folder becomes for
**non-GSD planning artifacts only** (architecture sketches, ad-hoc brainstorms, things
GSD doesn't generate). Specifically:

- Delete or stop maintaining: `00-planning/vision.md`, `requirements.md`, `roadmap.md`, `handoff.md` (GSD's `PROJECT.md`, `REQUIREMENTS.md`, `ROADMAP.md`, `STATE.md` replace them).
- Keep: `00-planning/design.md` (architecture), `01-features/` (mini-specs that complement GSD phases), `02-notes/`.
- Let GSD write `AGENTS.md`. Our scaffold's `AGENTS.md` becomes a starting template GSD will rewrite when you run `/gsd-new-project` — that's OK, but **back it up first** if you've heavily customized it.

### Mode B — **Docs-led** (good if you're not sure about GSD yet, or only want its execution loop)
Keep our `00-planning/*.md` files as the source of truth. Use only GSD's *execution* commands (`/gsd-execute-phase`, `/gsd-verify-work`) and point them at your existing specs.

- Risk: you'll be writing the same info in two places. Pick this only if you have a reason.

**Don't run both.** If `AGENTS.md` says one thing and `PROJECT.md` says another, every agent will pick the wrong one half the time.

---

## How this fits multi-CLI

GSD installs its skills/commands to runtime-specific paths:
- Claude Code → `~/.claude/skills/gsd-*/`
- Codex → `~/.codex/skills/gsd-*/`
- (similar per runtime)

That's **outside** this repo, so installing GSD doesn't pollute your project's `skills/`
folder. Your project-local skills and GSD's global skills coexist fine.

**Multi-CLI + GSD rules:**
1. GSD-generated artifacts at the project root (`PROJECT.md`, `REQUIREMENTS.md`, etc.) ARE committed to git — that's how every CLI shares state.
2. `.planning/config.json` is committed too, so model profiles and workflow settings are reproducible.
3. Don't run GSD commands from two CLIs on the same branch simultaneously. One driver at a time.
4. After any GSD run, `STATE.md` is the new handoff log — read it before switching tools.

---

## Useful GSD docs to bookmark
- User Guide: `docs/USER-GUIDE.md` in the repo
- Commands reference: `docs/COMMANDS.md`
- Configuration: `docs/CONFIGURATION.md`
- Architecture: `docs/ARCHITECTURE.md`
- Changelog (frequent major releases): `CHANGELOG.md`

If anything in this file disagrees with the upstream repo, trust the upstream — GSD ships
fast and this doc may lag behind. Always sanity-check the current command names and
install instructions against `open-gsd/get-shit-done-redux` before a fresh install.
