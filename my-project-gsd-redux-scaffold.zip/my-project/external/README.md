# external/

External repos and frameworks you depend on or reference — kept SEPARATE from your
own code in `src/`. Agents must NOT edit anything in here (see AGENTS.md §7); wrap or
extend it from `src/` instead.

## Two ways to bring a repo in

**A) Git submodule** (you want to track a specific upstream repo, get updates, maybe contribute back):
```
git submodule add <repo-url> external/<name>
git submodule update --init --recursive   # after cloning the project
```

**B) Plain clone / copy into `external/_reference/`** (you just want to read it for patterns, not track it):
```
git clone --depth 1 <repo-url> external/_reference/<name>
```
Reference copies are gitignored by default so they don't bloat your repo.

## Tools that install themselves (like GSD)
Some systems aren't "repos you clone" — they're installed via a package manager and
drop their own files into your project. See `external/GSD-INTEGRATION.md`.

## Rule of thumb
- Code you call as a dependency -> submodule in `external/`.
- Code you only read for inspiration -> `external/_reference/` (gitignored).
- A workflow system that generates commands/specs -> install per its docs, commit what it generates.
