# CLAUDE.md — Claude Code entry point

> The real rules live in AGENTS.md (the single source of truth for every agent).
> This file imports it and adds Claude-Code-specific notes only.

@AGENTS.md

## Claude-Code-specific notes
<!-- Only things unique to Claude Code go here. Never duplicate or contradict AGENTS.md. -->
- Use **plan mode** for any non-trivial task before editing files.
- Slash commands & subagents live in `.claude/` (if/when you add them).
- Project-local skills in `skills/` are auto-discovered; read the relevant one before the task.

## When using GSD Redux
- GSD will REWRITE `AGENTS.md` when you run `/gsd-new-project`. If you've customized it,
  commit first so you can recover anything important.
- GSD installs its skills to `~/.claude/skills/gsd-*/` (global, outside this repo).
- Run as `claude --dangerously-skip-permissions` per GSD's design.
- After installing GSD, **restart Claude Code** so the new commands load.

> If `@AGENTS.md` import isn't picked up by your version, paste AGENTS.md's contents in here
> — but keep AGENTS.md as the file you actually edit.
