# tests

Tests mirror the structure of `src/`. See `skills/example-skill/SKILL.md` for conventions.
