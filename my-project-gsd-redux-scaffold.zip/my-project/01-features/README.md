# Features

One folder per feature. To start a new one:
1. Copy `_template/` to `01-features/my-feature-name/`
2. Fill in requirements -> design -> tasks (in that order)
3. Point your AI at that folder when building it
