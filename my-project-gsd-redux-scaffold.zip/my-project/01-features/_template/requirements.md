# Feature: <name> — Requirements

## What & why
One paragraph: what this feature does and why it matters.

## Acceptance criteria
- [ ] When <situation>, the system <behavior>
- [ ] ...
