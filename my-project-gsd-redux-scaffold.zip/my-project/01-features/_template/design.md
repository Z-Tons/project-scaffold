# Feature: <name> — Design

## Approach
How you'll build it. Files touched, new pieces added.

## Edge cases
- What happens when...?
