# Skills

A "skill" is a reusable instruction module — a folder with a `SKILL.md` that teaches an
agent *how you do a specific kind of task*. The same `SKILL.md` format works in BOTH
Claude Code and Codex, so one skill folder serves every CLI.

## Format
Each skill = one folder with a `SKILL.md` that has YAML frontmatter (`name`, `description`)
and instructions. Add example files or scripts alongside it if useful.

## Registering skills per tool
- **Claude Code:** skills in `skills/` are auto-discovered. Just reference them.
- **Codex:** register each in `.codex/config.toml` with a `[[skills.config]]` block
  pointing at the `SKILL.md` path (already set up for the example skill).
- Both use *progressive disclosure*: the agent sees name + description first, and loads
  the full SKILL.md only when it decides to use the skill — so keep descriptions sharp.

## To add a skill
1. Copy `example-skill/` to `skills/<your-skill>/`.
2. Edit its `SKILL.md` (good `description` = when to use it).
3. Add a `[[skills.config]]` entry in `.codex/config.toml` for Codex.
