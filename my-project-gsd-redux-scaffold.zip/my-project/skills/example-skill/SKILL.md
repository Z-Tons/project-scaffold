---
name: writing-tests
description: How we write and run tests in this project. Use whenever adding or changing code that needs test coverage.
---

# Skill: Writing tests

## When to use this
Any time you add a feature or fix a bug in `src/`.

## How we do it here
1. Put tests in `tests/`, mirroring the structure of `src/`.
2. Name test files `test_<thing>.<ext>`.
3. Cover: the happy path, one edge case, and one failure case.
4. Run the full test suite before saying a task is done.

## Example
<!-- Replace with a real example from your stack so the AI copies the right style -->
```
# tests/test_example.ext
test "does the obvious thing" { ... }
test "handles empty input"   { ... }
```

## Done means
- [ ] New tests pass
- [ ] Existing tests still pass
