# src

Your actual code lives here. Structure it to match `00-planning/design.md`.
