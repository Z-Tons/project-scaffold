# Vision

## The one-liner
TODO: "<App> helps <who> do <what> so they can <benefit>."

## The problem
What's broken or annoying today? Why does this need to exist?

## Who it's for
Describe the main user in a sentence or two.

## What success looks like
- [ ] A concrete sign you'll know it's working
- [ ] Another one

## Explicitly NOT doing (for now)
Listing what's out of scope keeps the AI from wandering.
- Not building X
- Not supporting Y yet
