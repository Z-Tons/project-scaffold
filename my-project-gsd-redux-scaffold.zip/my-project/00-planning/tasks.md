# Task Board

> The single source of truth for "what now." Keep it current.
> When GSD is active, GSD's plan files (`.plans/`) supersede this for execution; keep
> this file for non-GSD or human-led work.

## Doing now
- [ ] Fill in `AGENTS.md` §1 (what we're building) and §2 (tech stack)
- [ ] Decide GSD mode in `02-notes/decisions/0002-gsd-mode.md` (A / B / C)

## Up next
- [ ] If using GSD: install (`npx @opengsd/get-shit-done-redux@latest`), restart CLI, run `/gsd-new-project`
- [ ] If docs-led: fill in `00-planning/vision.md` → `requirements.md` → `design.md` → `roadmap.md`
- [ ] Spec the first feature in `01-features/<name>/`
- [ ] Verify Codex CLI version is ≥ 0.130.0 (if using Codex)

## Done
- [x] Set up project structure
- [x] Wire AGENTS.md as multi-CLI source of truth
- [x] Document GSD Redux integration + file ownership

## Blocked / questions
- (none)
