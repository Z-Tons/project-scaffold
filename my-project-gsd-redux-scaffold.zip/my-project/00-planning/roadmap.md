# Roadmap

> Phases, not deadlines. Ship the smallest useful version first.

## Phase 1 — Walking skeleton
Goal: the simplest end-to-end version that does *one* real thing.
- [ ] ...

## Phase 2 — Make it useful
- [ ] ...

## Phase 3 — Make it nice
- [ ] ...
