# Requirements

> What the thing must do. Written before design or code.

## Must have (v1)
- [ ] R1: ...
- [ ] R2: ...

## Nice to have (later)
- [ ] R10: ...

## Constraints
- Budget / time / platform limits
- Anything it must work with (existing tools, data, devices)
