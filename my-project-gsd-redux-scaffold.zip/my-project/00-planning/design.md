# Design

> How it's built. The blueprint the AI codes against.

## Architecture (the big picture)
A few sentences on how the pieces fit. A simple list or diagram helps.

```
[ user ] -> [ frontend ] -> [ backend / logic ] -> [ data ]
```

## Key components
| Component | Responsibility |
|---|---|
| ... | ... |

## Data model
What are the main "things" (users, items, orders...) and their fields?

## Open questions
- [ ] Anything undecided. Resolve before building that part.
