# GitHub Copilot — the source of truth is AGENTS.md at the repo root.
Read AGENTS.md and 00-planning/handoff.md before suggesting or editing code.
Do not contradict AGENTS.md §1–§8.
